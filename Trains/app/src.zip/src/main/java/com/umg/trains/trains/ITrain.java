package com.umg.trains.trains;

public interface ITrain {
    public int getDefense();

    public int getOffense();
}
