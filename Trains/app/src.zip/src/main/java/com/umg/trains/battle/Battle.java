package com.umg.trains.battle;

public class Battle {
    private final int playerId = 0;
    private final int enemyId = 1;
    private final Player[] players = new Player[2];

    public Battle(Player player, Player enemy) {
        players[playerId] = player;
        players[enemyId] = enemy;
    }

    public void startGame() {
    }

    public void loadProgress(int player) {
        players[player].updateProgress(players[player].getTrain().getDamage());

        if (players[player].isLoaded())
            shoot(player);
    }

    public void shoot(int player) {
        if (player == playerId) {
            players[playerId]
        }
    }

}
