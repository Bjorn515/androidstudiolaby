package com.umg.trains.trains;

public interface ITrainAdapter {

    void onTrainSelect(Train train);

}
