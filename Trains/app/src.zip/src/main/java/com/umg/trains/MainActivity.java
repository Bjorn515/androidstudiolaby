package com.umg.trains;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    boolean appExited = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        System.out.println("CREATE");

        Button startButton = findViewById(R.id.startButton);
        startButton.setOnClickListener(view -> startGame());
    }

    public void startGame() {
        Intent intent = new Intent(getApplicationContext(), ChooseTrain.class);
        startActivity(intent);
    }

    @Override
    protected void onPause() {
        this.appExited = true;
        super.onPause();
    }

    @Override
    protected void onResume() {
        if (appExited)
            Toast.makeText(getApplicationContext(), getString(R.string.resume), Toast.LENGTH_LONG).show();

        this.appExited = false;
        super.onResume();
    }

    @Override
    protected void onDestroy() {
        System.out.println("ON DESTROY");
        super.onDestroy();
    }
}